package com.imooc.ad.search.vo.feature;

/**
 * Created by Qinyi.
 */
public enum FeatureRelation {

    OR,
    AND
}
