package com.imooc.ad.exception;

/**
 * Created by Qinyi.
 */
public class AdException extends Exception {

    public AdException(String message) {
        super(message);
    }
}
