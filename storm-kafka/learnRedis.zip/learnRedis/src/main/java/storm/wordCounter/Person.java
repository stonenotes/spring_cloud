package storm.wordCounter;

/**
 * Describe: 请补充类描述
 * Author:   maoxiangyi
 * Domain:   www.itcast.cn
 * Data:     2015/12/10.
 */
public class Person {

    public void open() {
        System.out.println("init.....");
    }

    public void ask() {
        System.out.println("an apple a day keeps the doctor away");
    }

    public void execute(String message) {
        System.out.println(message);
    }
}
